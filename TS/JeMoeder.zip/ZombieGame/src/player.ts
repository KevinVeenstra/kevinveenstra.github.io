class Player {

    constructor() {
        
    }

    
}