class Zombie {

    constructor() {
        
    }
}