class Game {

    private readonly canvas: Canvas;
    public player: Player

    constructor() {
        const canvasElement: HTMLCanvasElement = <HTMLCanvasElement>document.getElementById("canvas");
        this.canvas = new Canvas(canvasElement);
        console.log("in Game constructor")
    }


}

window.addEventListener("load", init);

function init(): void {
    const zombieGame = new Game();
    const player = new Player();
}
